import pandas as pd
import numpy as np
import sklearn
import pickle
import time
import re
from keras.preprocessing import sequence
from keras.models import Sequential
from keras.layers.core import Dense,Dropout,Activation
from keras.layers.embeddings import Embedding
from keras.layers.recurrent import LSTM,GRU
from keras.callbacks import TensorBoard,Callback#Callback用于自己创建一个类
from sklearn.model_selection import train_test_split
from sklearn.metrics import roc_curve,auc,precision_recall_curve,f1_score
import matplotlib.pyplot as plt
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score
from sklearn.model_selection import GridSearchCV
from numpy import inf
from keras.layers.convolutional import Conv1D,MaxPooling1D
from keras.layers.normalization import BatchNormalization
from keras.utils import plot_model
from read_big_data import read_data
from sklearn.metrics import accuracy_score
from numpy import inf
from keras.layers.convolutional import Conv1D,MaxPooling1D
from keras.layers.normalization import BatchNormalization
from sklearn.linear_model.logistic import LogisticRegression

class loss_auc_acc_history(Callback):#继承了Callback抽象类
    def __init__(self,training_data,validation_data):
        self.train_dns=training_data[0]
        self.train_label=training_data[1]
        self.val_dns=validation_data[0]
        self.val_label=validation_data[1]

    def on_train_begin(self, logs={}):
        self.loss=[]
        self.acc=[]
        #self.validation_loss=[]
        #self.validation_acc=[]
        self.auc=[]
        self.auc_validation=[]
        self.acc_val=[]
        self.val_loss_per_epoch=[]
        self.train_loss_per_epoch=[]
        self.val_acc_per_epoch = []
        self.train_acc_per_epoch = []

    def on_batch_end(self, batch, logs={}):
        self.loss.append(logs.get('loss'))
        self.acc.append(logs.get('acc'))


    def on_epoch_end(self, epoch, logs={}):
        if (epoch+1)%3==0:
            train_predict = self.model.predict(self.train_dns)
            val_predict = self.model.predict(self.val_dns)
            train_auc = sklearn.metrics.roc_auc_score(self.train_label, train_predict)
            val_auc = sklearn.metrics.roc_auc_score(self.val_label, val_predict)
            self.auc.append(train_auc)
            self.auc_validation.append(val_auc)
            logs['val_auc'] = val_auc
            logs['auc'] = train_auc
            print('AUC - epoch:%d - score on train_set:%.6f' % (epoch + 1, logs['auc']))
            print('AUC - epoch:%d - score on val_set:%.6f' % (epoch + 1, logs['val_auc']))
        self.train_loss_per_epoch.append(logs.get('loss'))
        self.train_acc_per_epoch.append(logs.get('acc'))
        self.val_loss_per_epoch.append(logs.get('val_loss'))
        self.val_acc_per_epoch.append(logs.get('val_acc'))

def read_dga(path,black_0__white_1):
    '''
    读取dga数据
    :param path:数据集地址(str)
    :param black_0__white_1: as the name said
    :return: Pandas.DataFrame
    '''
    data=pd.DataFrame(columns=['all','white'])#白色域名为1，黑色则为0
    f=open(path,'r')
    ls_db=[]
    for line in f:
        line=line.strip('\n').strip('\t').strip('.')
        ls_db.append({'all':line,'white':black_0__white_1})
    data=data.append(ls_db,ignore_index=True)
    f.close()
    return data

def gen_dga_dataframe(path_black,path_white,shuffle=True):
    '''
    读取黑白数据集并产生一个pandas的数据集
    :param path_black: black数据的地址
    :param path_white: white数据的地址
    :param shuffle: 是否要打乱数据
    :return: pandas.DataFrame
    '''
    data_black = read_dga(path_black, 0)
    data_white = read_dga(path_white, 1)
    df = pd.concat([data_black, data_white], axis=0, ignore_index=True)
    if(shuffle):
        df = df.sample(frac=1).reset_index(drop=True)
    return df

def read_dns(path,black_0__white_1):
    '''
    读取dns数据
    :param path: dns数据集地址(str)
    :param black_0__white_1: as the name said
    :return: pandas.DataFrame
    '''
    data=pd.DataFrame(columns=['all','white'])
    f=open(path,'r')
    for line in f:
        tmp_str=''
        tmp_str=line.strip('[').strip(']').split('|')[15]
        if '0000;'in tmp_str:
            tmp_str=tmp_str=line.strip('[').strip(']').split('|')[14]
        tmp_row={'all':tmp_str,'white':black_0__white_1}
    data.append(tmp_row,ignore_index=True)
    f.close()
    return data

#Rnn building
def gen_net(max_features,max_len):
    '''
    generate a LSTM Rnn
    :param max_features: 降维前数据的编码长度
    :param max_len: 输入的序列长度
    :return: lstm net
    '''
    net=Sequential()
    net.add(Embedding(max_features,128,input_length=max_len))#将输入的数据降维成128维的数据
    net.add((Dense(128)))
    net.add(BatchNormalization())
    net.add(Activation('relu'))
    net.add(Dropout(0.2))
    net.add(Conv1D(filters=256,padding='same',kernel_size=2,use_bias=True))#filter=256
    net.add(Activation('relu'))
    net.add(MaxPooling1D())
    net.add(Dropout(0.1))
    net.add(Conv1D(filters=256,padding='same',kernel_size=4,use_bias=True))
    net.add(BatchNormalization())
    net.add(Activation('relu'))
    net.add(MaxPooling1D())
    net.add(Dropout(0.2))#0.1
    net.add(Conv1D(filters=128,kernel_size=4,padding='same',use_bias=True))#k=6
    net.add(BatchNormalization())
    net.add(Activation('relu'))
    net.add(MaxPooling1D())
    net.add(Dropout(0.2))#0.15
    net.add((Dense(128)))
    net.add(BatchNormalization())
    net.add(Activation('relu'))
    net.add(Dropout(0.2))
    net.add(LSTM(128))
    net.add(Dropout(0.55))#0.6#0.4
    net.add(Dense(1))
    net.add(Activation('sigmoid'))
    net.compile(loss='binary_crossentropy',optimizer='rmsprop',metrics=['accuracy'])#作为model的优化器
    return net

def gen_dic(save_or_not=True):
    '''
    产生一个用于对网址基本字符编码的字典
    :param save_or_not:用于控制使用时是否要保存所产生的字典
    :return: 字典,字典长度
    '''
    str0='qwertyuiopasdfghjklzxcvbnmQWERTYUIOPASDFGHJKLZXCVBNM1234567890.%/=_~+-'
    dic={x:idx+1 for idx,x in enumerate(''.join(str0))}#0用来做填充用
    str_dic = 'dic_test.pkl'
    if save_or_not:
        f_dic = open(str_dic, 'wb')
        pickle.dump(dic, f_dic)
        f_dic.close()
    return dic,len(dic)

def gen_dic_r(dic_path):
    with open(dic_path,'rb') as f:
        dic=pickle.load(f)
    return dic,len(dic)

def activate(data,dic_path,model_name,max_epoch=35,batch_size=128,visuallize=False,train_all=False):
    '''
    训练lstm同时保存网络至model.pkl
    :param data: pandas.DataFrame
    :param max_epoch: 训练的最大次数
    :param batch_size: 用于优化算法的批大小
    :param train_all:是否要使用全部数据进行训练
    :return: 训练中的log
    '''
    time_str=str(time.asctime(time.localtime(time.time()))).replace(':','_')
    dns=[x['all'] for index,x in data.iterrows()]#读取DNS域名
    label=[x['white'] for index,x in data.iterrows()]#读取标签(1 for white and 0 for black)

    vaild_chars_dic,diclen=gen_dic_r(dic_path)#固定字符编码,

    max_features=len(vaild_chars_dic)+1#多出来的一个用来填充用
    max_len=55
    #max_len=np.max([len(x) for x in dns])#最长的序列长度
    #将字母转成编码
    dns_encrypt=[]#嵌套列表
    for x in dns:
        tmp=[]
        for y in x:
            tmp.append(vaild_chars_dic[y])
        dns_encrypt.append(tmp)
    dns_encrypt=sequence.pad_sequences(dns_encrypt,max_len)#填充列表，使得列表大小统一化
    out=[]
    print('>>>network building')
    model=gen_net(max_features,max_len)
    best_iter = -1
    best_auc = 0.0
    out_data = {}
    i=1
    if not visuallize:#不使用图片来可视化模型，优点：可动态调整训练次数>>>默认使用这种训练方法<<<
        tensorboard = TensorBoard(log_dir='mylog')
        callback_ls = [tensorboard]
        dns_train, dns_test, \
        label_train, label_test = train_test_split(dns_encrypt, label, test_size=0.2)
        # 取0.2的数据作为test
        dns_train_splt, dns_hold,\
        label_train_splt, label_hold = train_test_split(dns_train, label_train,test_size=0.05)
        for epoch in range(max_epoch):
            model.fit(dns_train_splt,label_train_splt,batch_size=batch_size,callbacks=callback_ls)
            t_probs=model.predict_proba(dns_hold)
            t_auc=sklearn.metrics.roc_auc_score(label_hold,t_probs)

            print('>>>',i,'th epoch out of',max_epoch,'training')
            i+=1
            print('>>>auc on hold_set:',t_probs)
            if t_auc>best_auc:
                best_auc=t_auc
                best_iter=epoch
                probs=model.predict_proba(dns_test)
                out_data={
                  'auc_in_(0.2)trainset':sklearn.metrics.roc_auc_score(label_test,probs),\
                  'confusion_matrix':sklearn.metrics.confusion_matrix(label_test,probs>0.5)}
                print('>>>auc_in_(0.2)trainset',out_data['auc_in_(0.2)trainset'])
                print('>>>tmp_out_data:{}'.format(out_data))
            else:
                if(epoch-best_iter>4):
                    break
        out.append(out_data)
        print(out[-1])
        strx = 'model_conv_lstm_2.pkl'
        f = open(strx, 'wb')
        pickle.dump(model, f)
        f.close()
        return out
    else:#使用图片来可视化模型
        if not train_all:
            dns_train_v,dns_hold_v,label_train_v,label_hold_v=train_test_split(dns_encrypt, label,test_size=0.05)
            history=loss_auc_acc_history((dns_train_v,label_train_v),(dns_hold_v,label_hold_v))
            cbk_ls=[history]#callback list
            epoch_visual=eval(input('输入要训练的epoch:'))
            model.fit(dns_train_v,label_train_v,batch_size=batch_size,epochs=epoch_visual,\
                          callbacks=cbk_ls,validation_split=0.1)
            #画loss and acc曲线
            fig = plt.figure(figsize=(18, 9))
            plt.plot(np.arange(len(history.acc)), history.acc)
            plt.xlabel('epoch')
            plt.plot(np.arange(len(history.loss)), history.loss)
            plt.legend(['acc_train', 'loss_train'])
            plt.title('preformance' + time_str)
            probs = model.predict_proba(dns_hold_v)
            plt.annotate('auc_val on test_set {:.5f} at {}'.format(sklearn.metrics.roc_auc_score(label_hold_v, probs), \
                                                                   time_str),
                         xy=(600, 0.5))
            fig.savefig('loss_and_acc_performance' + time_str + '.png')
            # 画auc曲线
            fig_1 = plt.figure(figsize=(18, 9))
            plt.plot(np.arange(len(history.auc)) + 1, history.auc)
            plt.plot(np.arange(len(history.auc_validation)) + 1, history.auc_validation)
            plt.legend(['auc_train', 'auc_test'])
            fig_1.savefig('auc_performance.png' + time_str + '.png')
            # 画交叉验证集上的loss和acc曲线
            fig_2 = plt.figure(figsize=(18, 9))
            plt.plot(np.arange(len(history.train_acc_per_epoch)) + 1, history.train_acc_per_epoch)
            plt.plot(np.arange(len(history.train_loss_per_epoch)) + 1, history.train_loss_per_epoch)
            plt.plot(np.arange(len(history.val_acc_per_epoch)) + 1, history.val_acc_per_epoch)
            plt.plot(np.arange(len(history.val_loss_per_epoch)) + 1, history.val_loss_per_epoch)
            plt.legend(['train_acc', 'train_loss', 'val_acc', 'val_loss'])
            fig_1.savefig('validation_performance.png' + time_str + '.png')
            strx = model_name+'.pkl'
            f = open(strx, 'wb')
            pickle.dump(model, f)
            f.close()
            return strx,dns_train_v,label_train_v,dns_hold_v,label_hold_v,batch_size,model_name
        else:#train_all=True
            epoch=eval(input('输入要训练的步数:'))
            model.fit(dns_encrypt, label,batch_size=batch_size,epochs=epoch)
            strx = model_name+'.pkl'
            f = open(strx, 'wb')
            pickle.dump(model, f)
            f.close()

def load_model(path_model):
    with open(path_model, 'rb') as f:
        model = pickle.load(f)
    return model

def further_training(model_path,dns_train,label_train,dns_hold,label_hold,batch_size,model_name):
    '''
    继续训练更多的步数
    :param model_path:模型的路径
    :param dns_train:编码后的域名
    :param label_train:validation data，用来画图
    :param dns_hold：同上
    :param:batch_size :批大小
    :return:
    '''
    time_str=str(time.asctime(time.localtime(time.time()))).replace(':','_')
    epoch = eval(input('输入要训练的步数:'))
    history=loss_auc_acc_history((dns_train,label_train),(dns_hold,label_hold))
    cbk_ls=[history]
    model=load_model(model_path)
    model.fit(dns_train,label_train,batch_size=batch_size,epochs=epoch,callbacks=cbk_ls)
    #画auc曲线
    fig = plt.figure(figsize=(18, 9))
    plt.plot(np.arange(len(history.acc)), history.acc)
    plt.xlabel('epoch')
    plt.plot(np.arange(len(history.loss)), history.loss)
    plt.legend(['acc_train', 'loss_train'])
    plt.title('preformance' + time_str)
    probs = model.predict_proba(dns_hold)
    plt.annotate('auc_val on test_set {:.5f} at {}'.format(sklearn.metrics.roc_auc_score(label_hold, probs),\
                                                           time_str),
                 xy=(600, 0.5))
    fig.savefig(str('train_loss_and_acc_performance'+time_str+'.png'))
    #画loss和acc曲线
    fig_1 = plt.figure(figsize=(18, 9))
    plt.plot(np.arange(len(history.auc)) + 1, history.auc)
    plt.plot(np.arange(len(history.auc_validation)) + 1, history.auc_validation)
    plt.legend(['auc_train', 'auc_test'])
    fig_1.savefig(str('auc_performance'+time_str+'.png'))
    #画交叉验证集上的loss和acc曲线
    fig_2 = plt.figure(figsize=(18, 9))
    plt.plot(np.arange(len(history.train_acc_per_epoch)) + 1, history.train_acc_per_epoch)
    plt.plot(np.arange(len(history.train_loss_per_epoch)) + 1, history.train_loss_per_epoch)
    plt.plot(np.arange(len(history.val_acc_per_epoch)) + 1, history.val_acc_per_epoch)
    plt.plot(np.arange(len(history.val_loss_per_epoch)) + 1, history.val_loss_per_epoch)
    plt.legend(['train_acc', 'train_loss','val_acc','val_loss'])
    fig_1.savefig('validation_performance.png' + time_str + '.png')
    strx = model_name + '.pkl'
    f = open(strx, 'wb')
    pickle.dump(model, f)
    f.close()

def evaluate_model(path_model,path_dic,data,draw_curve=False,find_best_threshold=False):
    '''
    用来评价所训练出的模型
    :param path: 模型pickle文件的路径
    :param data: 训练模型从来没用过的数据集
    :param draw_curve:是否要画曲线
    :param find_best_threshold:根据f1值来找最佳的阈值
    :return:auc值，同时会绘制roc曲线
    '''
    time_str=str(time.asctime(time.localtime(time.time()))).replace(':','_')
    dns = [x['all'] for index, x in data.iterrows()]  # 读取DNS域名
    label = [x['white'] for index, x in data.iterrows()]  # 读取标签(1 for white and 0 for black)
    with open(path_dic,'rb') as di:
        vaild_chars_dic=pickle.load(di)
    # 找到域名中的有效字符,对这些字符编码
    # 多出来的一个用来填充用
    max_len = 55  # 最长的序列长度 ##（原来model的maxlen是50）
    # 将字母转成编码
    dns_encrypt = []  # 嵌套列表
    for x in dns:
        tmp = []
        for y in x:
            if (len(tmp) >= max_len):
                break
            tmp.append(vaild_chars_dic.get(y,0))
        dns_encrypt.append(tmp)
    dns_encrypt = sequence.pad_sequences(dns_encrypt, max_len)
    dns=dns_encrypt
    with open(path_model, 'rb') as f:
        model = pickle.load(f)
    predict = model.predict_proba(dns)
    if find_best_threshold:
        best_F1 = 0
        best_threshold = 0
        for i in np.arange(0, 1, 0.001):
            F1_tmp=f1_score(label,predict>i)
            if F1_tmp > best_F1:
                best_F1 = F1_tmp
                best_threshold = i
        print('best threshold=', best_threshold, '\nwith the best F1=', best_F1)
        fpr, tpr, thresholds = roc_curve(label, predict)
        AUC = auc(fpr, tpr)
        acc=accuracy_score(label,predict>best_threshold)
        f1=f1_score(label,predict>best_threshold)
        fig = plt.figure(figsize=(10, 10), dpi=100)
        plt.plot(fpr, tpr, label='ROC')
        plt.annotate('auc_val on test_set {:.5f}'.format(AUC), xy=(0.4, 0.6))
        plt.annotate('accuracy on test_set {:.5f}'.format(acc),xy=(0.4,0.7))
        plt.annotate('F1_score on test_set {:.5f}'.format(f1),xy=(0.4,0.8))
        plt.ylabel('True positive rate')
        plt.xlabel('False positive rate')
        plt.show()
        fig.savefig('auc_performance' + time_str + '.png')
        print('auc=', AUC)
    if (draw_curve):
        fpr, tpr, thresholds = roc_curve(label, predict)
        AUC = auc(fpr, tpr)
        fig=plt.figure(figsize=(10,10),dpi=100)
        plt.plot(fpr,tpr,label='ROC')
        plt.annotate('auc_val on test_set {:.5f}'.format(AUC),xy=(0.4,0.6))
        plt.ylabel('True positive rate')
        plt.xlabel('False positive rate')
        plt.show()
        fig.savefig('auc_performance'+time_str+'.png')
        print('auc=',AUC)

#main()
#data reading
with open('train_data.pkl','rb') as f:
    train_data=pickle.load(f)
with open('validation_data.pkl','rb') as f:
    validation_data=pickle.load(f)
with open('test_data.pkl','rb') as f:
    test_data=pickle.load(f)
with open('all_data.pkl','rb') as f:
    all_data=pickle.load(f)
dic_path='./dic_test.pkl'
###TODO:The following code works for Training Lstm net
tpl=activate(train_data,dic_path,model_name='c-lstm_pro',batch_size=128,max_epoch=100,visuallize=True,train_all=False)
#TODO:如果已经调整好超参数了，想使用全部数据进行训练，则调用下一行代码
#activate(df_final,model_name='c-lstm_final',batch_size=128,max_epoch=100,visuallize=True,train_all=True)
##使用说明：现在activate会返回7个值，这里全部返回给tpl，tpl是一个元组 ,'./'+tpl[0]是模型路径
##使用说明：tpl[0]是模型路径名，tpl[1]是训练域名数据，tpl[2]是标签，
# tpl[3]是交叉验证的域名数据，tpl[4]是交叉验证的标签数据，tpl[5]是批的大小
#由上面注释可知further_training的参数
##further_training最后一行是再次训练的模型名称
#further_training('./'+tpl[0],tpl[1],tpl[2],tpl[3],tpl[4],tpl[5],'lstm_further')
#如果想再训练几次的话就再调用上面一行代码，同时，继续训练的模型名称可以自己定制


###TODO:The following code works for Evaluating the model trained
#TODO:model_path=,dic_path=
#TODO:validation_data用于调整超参数
# evaluate_model(model_path,dic_path,validation_data,draw_curve=True,find_best_threshold=False)
#TODO:test_data用于调整好超参数后查看测试集上的表现
# evaluate_model(model_path,dic_path,all_data,draw_curve=True,find_best_threshold=False)
#TODO:用于找最佳阈值
# evaluate_model(model_path,dic_path,all_data,draw_curve=False,find_best_threshold=True)
