import pandas as pd

class read_data():
    '''
    读取数据
    self._white_path=白样本数据集路径
    self._black_path=黑样本数据集路径
    self.db_white=白样本的pandas DF
    self.db_black=黑样本的pandas DF
    self.len_white=白样本数据的长度（可调用）
    self.len_black=黑样本数据的长度（可调用）
    self._normalize=是否要让黑白样本数据量相等（默认为是，可更改）
    '''
    def __init__(self,path_white,path_black,normalize=True):
        '''
        :param path_white: 白样本数据集路径
        :param path_black: 黑样本数据集路径
        :param normalize: 是否要让黑白样本数据量相等
        '''
        self._white_path=path_white
        self._black_path=path_black
        self.db_white=None
        self.db_black=None
        self._normalize=normalize
        self.len_white=0
        self.len_black=0
        self.len_max_white=0
        self.len_max_black=0


    def _read_white_dga(self):
        '''
        读取dga数据
        '''
        data = pd.DataFrame(columns=['all', 'white'])  # 白色域名为1，黑色则为0
        path=self._white_path
        f = open(path, 'r')
        ls_db = []
        for line in f:
            ls_tmp = line.split(',')
            line = ls_tmp[1].strip('\n').strip(' ')
            length=len(line)
            if length>self.len_max_white:
                self.len_max_white=length
            ls_db.append({'all': line, 'white': 1})
        data = data.append(ls_db, ignore_index=True)
        f.close()
        self.db_white=data
        self.len_white=len(data)

    def read_black_dga(self):
        '''
        读取dga数据
        '''
        data = pd.DataFrame(columns=['all', 'white'])  # 白色域名为1，黑色则为0
        path=self._black_path
        f = open(path, 'r')
        ls_db = []
        i=0
        for line in f:
            ls_tmp = line.split('\t')
            try:
                line = ls_tmp[1].strip(' ')
                length=len(line)
                if length > self.len_max_black:
                    self.len_max_black = length
            except:
                continue
            if self._normalize:#执行判断
                if i< self.len_white:
                    ls_db.append({'all': line, 'white': 0})
                else:
                    break
            else:
                ls_db.append({'all': line, 'white': 0})
            i += 1
        data = data.append(ls_db, ignore_index=True)
        f.close()
        self.db_black=data
        self.len_black=len(data)

    def gen_df(self,shuffle=True):
        '''
        读取黑白数据集并产生一个pandas的数据集
        :param shuffle: 是否要打乱数据
        :return: pandas.DataFrame
        '''

        self._read_white_dga()
        self.read_black_dga()
        df = pd.concat([self.db_black, self.db_white], axis=0, ignore_index=True)
        if (shuffle):
            df = df.sample(frac=1).reset_index(drop=True)
        return df
#
#test here
# file_path_360='C:/untitled6/data/DGA_Data/360_dga_black.txt'
# file_path_alexa='C:/untitled6/data/DGA_Data/alexa_dga_white.csv'
#
# db_read=read_data(file_path_alexa,file_path_360)
# df=db_read.gen_df()
# print(df)
# print('     black',db_read.len_black,'   white',db_read.len_white,'     black_max_len',db_read.len_max_black,\
#       '     white_max_len',db_read.len_max_white)
