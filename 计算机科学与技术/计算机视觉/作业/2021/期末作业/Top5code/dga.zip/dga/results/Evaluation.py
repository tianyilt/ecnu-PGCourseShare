import numpy as np
import pandas as pd
from tensorflow.python.keras.models import load_model
import h5py
from my_module import ConvLstm1D as mylayer
from tensorflow.python.keras.layers import ConvLSTM2D, Conv1D, Dense, Dropout, Embedding, BatchNormalization, \
    MaxPooling1D, Activation, Input, LSTM, add, GlobalAvgPool1D, concatenate, Bidirectional
import tensorflow as tf

def plain_convlstm1D_net(max_features, max_len, use_gap=True):
    '''
    Input=>Embedding=>ConvLSTM1D=>BN=>Dense1=>sigmoid
    '''
    net_input = Input(shape=(max_len,))
    hidden = Embedding(max_features, 128, input_length=max_len)(net_input)
    hidden = mylayer.ConvLSTM1D(filters=64, kernel_size=4, padding='same', use_gap=use_gap)(hidden)
    hidden = BatchNormalization()(hidden)
    hidden = Dense(1)(hidden)
    net_output = Activation('sigmoid')(hidden)
    model = tf.keras.Model(inputs=net_input, outputs=net_output)
    model.compile(loss='binary_crossentropy', optimizer='adam', metrics=['accuracy'])
    print('>>>Using the following model')
    print(model.summary())
    # plot_model(model,'plain_convlstm1D_net.png',show_shapes=True)
    return model

def import_test():
    print('you have imported Evaluation successfully:)')

def white_data_generator(filepath:str,num:int):
    if num>1000000:
        print('>>>num exceeded! will set num to 1000000')
        num=1000000
    df=pd.read_csv(filepath)
    index=sorted(list(np.random.randint(0,99999,(num,))))
    return df.loc[index]

def hdf5_cracker(modelpath:str):
    try:
        model = load_model(modelpath)
        print(model.summary())
    except:
        try:
            print('>>>keras reading failed!\n>>>using h5py to read the model')
            weights=h5py.File(model_path,'r')['model_weights']
            model=plain_convlstm1D_net(128,75)
            model.load_weights(model_path)
            print(model.summary())

        except:
            print('>>>failed to read the model')

#a=white_generator('alexa_10w.csv',100)
model_path='plain_convlstm1D_net_Mon Oct 14 04_47_00 201926-0.05.hdf5'
model = plain_convlstm1D_net(128, 75)
model.load_weights(model_path)
print(model.summary())
1==1