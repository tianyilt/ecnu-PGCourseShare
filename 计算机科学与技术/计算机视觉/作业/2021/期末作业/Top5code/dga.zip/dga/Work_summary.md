# 已经实现的：

1. Residue block with pre-activaction 记为 rpb

2. ResNeXt-like Residue block 记为 rxb

3. Conv-Lstm1D 记为convlstm1d

# 需要去尝试的

**多层感知机记为 MLP**

**LSTM记为lstm**

**Conv1D记为Conv1D**

**均省去了Embedding 层 和最后的 sigmoid 层**

1. convlstm1d

2. rpb+convlstm1d

3. rxb+convlstm1d

4. lstm

5. rpb+lstm

6. rxb+lstm

7. MLP

8. MLP+convlstm1d

9. MLP+lstm

10. Conv1D+lstm

10. Conv1D+convlstm1d
