# DGA-detector
Using conv and Lstm to detect dga domain
Try to find a best dga detector using neuro networks.
Specifically,Conv1D,LSTM,ConvLstm1D.

## Requirements:

python==3.7.3

matplotlib==3.1.0

numpy==1.16.4

pandas==0.24.2

sklearn==0.21.2


**tensorflow==1.14.0**

## How to Use
	git clone https://github.com/g-ernade/DGA-detector.git

	cd DGA-detector

	conda env create -f environment.yaml

	conda activate DGA-detector

TODO

## Structure used in this project:

### LSTM
![LSTM](./assets/lstm.png "lstm")
### Global pooling
![Global pooling](./assets/global_pooling.png "global_pooling")
### Residue blocks
![pre-activated residue block](./assets/preactivated_residueblock.jpg "pre-activated")
![ ](./assets/preactivated_residueblock_1.png)
![ResNext](./assets/resnext_1.png " ResNext")
![ ](./assets/resnext_2.png)


## Relevant URLs

>>[overview](https://www.cnblogs.com/ahuzcl/p/11135111.html)

>>[pre-activated residue block](https://www.cnblogs.com/nowgood/p/ResNet.html)

>>[resnext](https://blog.csdn.net/xzy528521717/article/details/86582889)

>>[global pooling](https://blog.csdn.net/duanyajun987/article/details/82108006)

>>[LSTM](https://blog.csdn.net/zhangbaoanhadoop/article/details/81952284)

>>[ConvLstm](https://blog.csdn.net/m0_37622530/article/details/81079001)

>>[keras document in Chinese](https://keras.io/zh/)

>>>[Convolutional layer in keras](https://keras.io/zh/layers/convolutional/#conv1d)

>>>[LSTM & ConvLstm2D in keras](https://keras.io/zh/layers/recurrent/#lstm)

>>>[pooling in Keras](https://keras.io/zh/layers/pooling/)

>>[all test paper](http://faculty.washington.edu/mdecock/papers/byu2018a.pdf)



	
