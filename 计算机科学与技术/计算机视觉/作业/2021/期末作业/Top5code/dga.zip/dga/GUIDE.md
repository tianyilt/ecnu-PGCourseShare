当前训练脚本位于model_test(now)/train_script/ConvLstm1D_test.py

数据位于model_test(now)/train_script/data

训练脚本依赖于两个自定义的module

1. my_callback:位于model_test(now)

2.my_module:位于model_test(now)

# 改超参说明：

在训练脚本的末尾有如下代码，选择相应超参更改即可

对于最后一行代码，第一个参数是一个python函数，选择需要训练的模型并将***函数名***填入*train_K_Folds*第一个参数

```python

#设置训练参数：

training_on_such_data=small_data#用于训练的数据

epochs=2#训练的步数

batch_size=256#批大小

model_name='test_KFOLDS0'#当前训练出模型的名字

num_folds=3#几折交叉验证

train_K_Folds(resnext_convlstm1D_net,training_on_such_data,dic_for_encrypt,epochs,batch_size,model_name,fold_num=num_folds)

```

# 如何利用已有模块(preactivated_block,ResNext like block)去构建新的模型？

## 1.使用 preactivated_block

注意到训练脚本中有如下代码片段
```python

def build_a_serious_of_residue_blocks(nb_filters:int,kernel_size:int,nb_blocks:int,is_First_layer:bool=False):

    '''

    构建一系列残差块

    :param nb_filters:这一系列残差块的卷积核数量

    :param nb_blocks: 这一系列残差块的数量

    :param is_First_layer: 是否为第一层，若位于第一层，则第一个残差块步长为1

    :return:

    '''

    def f(input):

        for i in range(nb_blocks):

            print('block No{}:'.format(i))

            strides=1

            if i==0 and (not is_First_layer):

                strides=2#如果位于一系列残差块的第一个且不位于第一层，此时步长为2

            input=build_residue_block(nb_filters,kernel_size,strides)(input)

        return input

    return f

#残差块构建完成

#以上残差块实现的版本是fully-preactivated版本的残差块，可以用于带有Convlstm和lstm的设计当中
```

想在新的网络中使用preactivated_block,需要调用上述函数。上述函数如何使用，以源码中已经定义的一个网络为例：

```python
def res_convlstm1D_net(max_features,max_len,use_gap=True):#ResNet 18 like design

    #block0_input

    net_input=Input(shape=(max_len,))

    #conv1

    hidden_embed=Embedding(max_features,32,input_length=max_len)(net_input)#(?,48,32)

    hidden_start=Conv1D(filters=64,kernel_size=4,strides=2,padding='same')(hidden_embed)#(?,24,64)

    hidden_start=BatchNormalization()(hidden_start)

    hidden_start=Activation('relu')(hidden_start)

    #conv2

    conv=build_a_serious_of_residue_blocks(64,2,2,True)(hidden_start)

    #conv3

    conv=build_a_serious_of_residue_blocks(128,2,2)(conv)

    #conv4

    conv=build_a_serious_of_residue_blocks(256,2,2)(conv)

    #6 adds in total

    #info collection

    dense=Dense(128)(conv)

    hidden=mylayer.ConvLSTM1D(filters=64,kernel_size=3,padding='same',use_gap=use_gap)(conv)

    hidden = Dense(1)(hidden)

    net_output = Activation('sigmoid')(hidden)

    model = tf.keras.Model(inputs=net_input, outputs=net_output)

    model.compile(loss='binary_crossentropy', optimizer='adam', metrics=['accuracy'])

    print('>>>Using the following model')

    print(model.summary())

    # plot_model(model,'plain_convlstm1D_net.png',show_shapes=True)

    return model
```
![pre-activated residue block](./assets/preactivated_residueblock.jpg "pre-activated")

build_a_serious_of_residue_blocks(nb_filters:int,kernel_size:int,nb_blocks:int,is_First_layer:bool=False)

该函数用于定义一系列的残差块

nb_filters:用于定义该层有多少个滤波器

kernel_size:用于定义该层卷积核的大小

nb_blocks:用于定义该层有多少个残差块

is_First_layer:用于定义该层是否为第一层

## 2.使用 ResNext like block

注意到训练脚本中有如下代码片段

```python
#定义ResNeXt-like 的残差块
def build_a_serious_of_wide_residues(input_x,nb_split_filter,output_dim,nb_layers,k1:int,k2:int,is_First_layer=False):

    for i in range(nb_layers):

        strides = 1

        # if i == 0 and (not is_First_layer):

        #     strides = 2  # 如果位于一系列残差块的第一个且不位于第一层，此时步长为2

        x=splits_layer(input_x,stride=strides,filter_size=nb_split_filter,kernelsize1=k1,kernelsize2=k2)

        block_out=transit_all(x,output_dim,kernel_size=k1)#加入shortcut之前的输出

        concated=residue_concat(input_x,block_out)

        input_x=Activation('relu')(concated)

    return input_x

```

想在新的网络中使用ResNeXt-like block,需要调用上述函数。上述函数如何使用，以源码中已经定义的一个网络为例：

```python
def resnext_convlstm1D_net(max_features,max_len,use_gap=True):

    # block0_input

    net_input = Input(shape=(max_len,))

    # conv1

    hidden_embed = Embedding(max_features, 32, input_length=max_len)(net_input)  # (?,48,32)

    hidden_start = Conv1D(filters=64, kernel_size=4, strides=2, padding='same')(hidden_embed)  # (?,24,64)

    hidden_start = BatchNormalization()(hidden_start)

    hidden_start = Activation('relu')(hidden_start)

    #conv2

    conv=build_a_serious_of_wide_residues(hidden_start,2,128,3,2,4,True)

    #conv3

    conv=build_a_serious_of_wide_residues(conv,4,256,4,1,3,False)

    #conv4

    conv = build_a_serious_of_wide_residues(conv, 8, 256, 2, 2, 3, False)

    # info collection

    dense = Dense(128)(conv)

    hidden = mylayer.ConvLSTM1D(filters=64, kernel_size=3, padding='same', use_gap=use_gap)(conv)

    hidden = Dense(1)(hidden)

    net_output = Activation('sigmoid')(hidden)

    model = tf.keras.Model(inputs=net_input, outputs=net_output)

    model.compile(loss='binary_crossentropy', optimizer='adam', metrics=['accuracy'])

    print('>>>Using the following model')

    print(model.summary())

    # plot_model(model,'plain_convlstm1D_net.png',show_shapes=True)

    return model
```

![ ](./assets/resnext_2.png)

这里实现的是结构2

同时这个函数实现的是构建一系列的Resnext残差块

build_a_serious_of_wide_residues(input_x,nb_split_filter,output_dim,nb_layers,k1:int,k2:int,is_First_layer=False)

input_x:传入这一层的输入

nb_split_filter:32个小卷积层的滤波器数量

output_dim:这一层的输出

***output_dim==32*nb_split_filter***

nb_layers:这一些列残差块一共有多少个

k1:小残差块（前）的卷积核的大小

k2:小残差块（后）的卷积核的大小

is_First_layer:当为第一层是设置为True,见上述例子里面是怎么用的



